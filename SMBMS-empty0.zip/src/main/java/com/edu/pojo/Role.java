package com.edu.pojo;

import lombok.Data;

@Data
public class Role {
    private Integer id;
    private String roleCode;
    private String roleName;
}
