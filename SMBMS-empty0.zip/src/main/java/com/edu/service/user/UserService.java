package com.edu.service.user;

import com.edu.pojo.User;

import java.util.List;

public interface UserService {
    User getUserByCodeAndPwd(String userCode, String userPassword);

    List<User> queryUser(String userName, Integer roleId);

    User getUserByCode(String userCode);

    int addUser(User user);

    User getUserById(String id);

    int modifyUser(User user);

    boolean modifyUserPwd(int id, String password, int modifyBy);

    int deleteUser(Integer id);
}
