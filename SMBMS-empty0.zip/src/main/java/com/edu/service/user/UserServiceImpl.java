package com.edu.service.user;

import com.edu.dao.UserMapper;
import com.edu.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserMapper userMapper;

    @Override
    public User getUserByCodeAndPwd(String userCode, String Password) {
        return userMapper.getUserByCodeAndPwd(userCode, Password);
    }

    @Override
    public List<User> queryUser(String userName, Integer roleId) {
        return userMapper.queryUser(userName, roleId);
    }

    @Override
    public User getUserByCode(String userCode) {
        return userMapper.getUserByCode(userCode);
    }

    @Override
    public int addUser(User user) {
        return userMapper.addUser(user);
    }

    @Override
    public User getUserById(String id) {
        return userMapper.getUserById(id);
    }

    @Override
    public int modifyUser(User user) {
        return userMapper.modifyUser(user);
    }

    @Override
    public boolean modifyUserPwd(int id, String password, int modifyBy) {
        return userMapper.modifyUserPwd(id, password, modifyBy) > 0;
    }

    @Override
    public int deleteUser(Integer id) {
        return userMapper.deleteUser(id);
    }

}
