package com.edu.service.role;

import com.edu.pojo.Role;

import java.util.List;

public interface RoleService {
    public List<Role> queryRole();
}
