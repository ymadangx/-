package com.edu.service.provider;

import com.edu.dao.ProviderMapper;
import com.edu.pojo.Provider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProviderServiceIml implements ProviderService {
    @Autowired
    private ProviderMapper providerMapper;

    @Override
    public List<Provider> queryProvider() {
        return providerMapper.queryProvider();
    }

    @Override
    public List<Provider> queryProvider(String proCode, String proName) {
        return providerMapper.queryProvider(proCode, proName);
    }

    @Override
    public Provider queryProviderById(Integer id) {
        return providerMapper.queryProviderById(id);
    }

    @Override
    public int addProvider(Provider provider) {
        return providerMapper.addProvider(provider);
    }

    @Override
    public boolean modifyProvider(Provider provider) {
        return providerMapper.modifyProvider(provider) > 0;
    }

    @Override
    public boolean delProvider(Integer id) {
        int i = providerMapper.delProvider(id);
        System.out.println(i);
        return i > 0;
    }

}

