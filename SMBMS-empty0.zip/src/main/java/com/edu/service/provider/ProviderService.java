package com.edu.service.provider;

import com.edu.pojo.Provider;

import java.util.List;

public interface ProviderService {
    List<Provider> queryProvider();
    List<Provider> queryProvider(String proCode, String proName);
    Provider queryProviderById(Integer id);
    int addProvider(Provider provider);
    boolean modifyProvider(Provider provider);
    boolean delProvider(Integer id);

}
