package com.edu.dao;

import com.edu.pojo.Provider;
import com.edu.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ProviderMapper {
    List<Provider> queryProvider();

    List<Provider> queryProvider(@Param("proCode") String proCode, @Param("proName") String proName);

    Provider queryProviderById(Integer id);

    int addProvider(Provider provider);

    int modifyProvider(Provider provider);

    int delProvider(Integer id);
}
