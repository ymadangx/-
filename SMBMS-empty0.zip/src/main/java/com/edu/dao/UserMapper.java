package com.edu.dao;

import com.edu.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserMapper {

    User getUserByCodeAndPwd(@Param("userCode") String userCode, @Param("userPassword") String userPassword);

    List<User> queryUser(@Param("userName") String userName, @Param("roleId") Integer roleId);

    User getUserByCode(String userCode);

    int addUser(User user);

    User getUserById(String id);

    int modifyUser(User user);

    int modifyUserPwd(@Param("id") int id, @Param("userPassword") String userPassword, @Param("modifyBy") int modifyBy);

    int deleteUser(Integer id);
}
