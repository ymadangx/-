package com.edu.dao;

import com.edu.pojo.Role;

import java.util.List;

public interface RoleMapper {
    List<Role> queryRole();
}
