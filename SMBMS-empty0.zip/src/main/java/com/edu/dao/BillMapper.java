package com.edu.dao;

import com.edu.pojo.Bill;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BillMapper {
    List<Bill> queryBill(@Param("productName") String productName, @Param("providerId") Integer providerId, @Param("isPayment") Integer isPayment);

    int addBill(Bill bill);

    Bill getBillById(String id);

    int modifyBill(Bill bill);

    int deleteBill(Integer id);

}
