package com.edu.servlet;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.edu.pojo.Bill;
import com.edu.pojo.Provider;
import com.edu.pojo.User;
import com.edu.service.bill.BillService;
import com.edu.service.provider.ProviderService;
import com.edu.tools.Constants;
import com.edu.tools.ConvertUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PipedWriter;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static com.edu.tools.ConvertUtil.sendJsonMessage;

@Controller
public class BillServlet {
    @Autowired
    BillService billService;
    @Autowired
    ProviderService providerService;

    @RequestMapping("/queryBill")
    public String queryBill(HttpServletRequest request, String queryProductName, Integer queryProviderId, Integer queryIsPayment) {
        List<Bill> billList = billService.queryBill(queryProductName, queryProviderId, queryIsPayment);
        List<Provider> providerList = providerService.queryProvider();
        request.setAttribute("billList", billList);
        request.setAttribute("providerList", providerList);
        request.setAttribute("queryProductName", queryProductName);
        request.setAttribute("queryProviderId", queryProviderId);
        request.setAttribute("queryIsPayment", queryIsPayment);
        return "billlist";
    }

    @RequestMapping("/addBill")
    public String addBill(HttpServletRequest request, HttpServletResponse response, String billCode, String productName, String productUnit, Double productCount, Double totalPrice, Integer providerId, Integer isPayment) throws IOException {
//     public String addBill(HttpServletRequest request, HttpServletResponse response, bill bill){
        Bill bill = new Bill();
        bill.setBillCode(billCode);
        bill.setProductName(productName);
        bill.setProductUnit(productUnit);
        bill.setProductCount(productCount);
        bill.setTotalPrice(totalPrice);
        bill.setProviderId(providerId);
        bill.setIsPayment(isPayment);
//        通过session获取当前用户信息
        User user = (User) request.getSession().getAttribute(Constants.USER_SESSION);
        bill.setCreatedBy(user.getId());
//        设置新建订单时间
//        billService.addBill(bill);
        bill.setCreationDate(new Date());
        int result = billService.addBill(bill);
        if (result > 0) {
            //和转发
//            request.getRequestDispatcher("/queryBill").forward(request, response);
//            return null;
//            重定向
//
//            response.sendRedirect( "/queryBill");
//            return null;
            return "redirect:/queryBill";
//            return "billlist";
        }
        return "billadd";
    }

    @RequestMapping("getBillById")
    public void getBillById(HttpServletRequest request, HttpServletResponse response, String id) throws IOException {

        Bill bill = billService.getBillById(id);
        String jsonstr = JSON.toJSONString(bill);
        ConvertUtil.sendJsonMessage(response, jsonstr);
//        request.setAttribute("bill",bill);
//        response.setContentType("application/json");
//        PrintWriter printWriter = response.getWriter();
//        printWriter.write(JSON.toJSONString(bill));
//        printWriter.flush();
    }

    @RequestMapping("/billModify")
    public String modifyBill(HttpServletRequest request, Bill bill) {
        User user = (User) request.getSession().getAttribute(Constants.USER_SESSION);
        bill.setModifyBy(user.getId());
        bill.setModifyDate(new Date());
        int result = billService.modifyBill(bill);
        if (result > 0) {
            return "redirect:/queryBill";
        } else {
            return "billmodify";
        }
    }

    @RequestMapping("/delBill")
    public void deletBill(HttpServletRequest request, HttpServletResponse response, Integer id) throws IOException {
        int result = billService.deleteBill(id);
        HashMap<String, String> map = new HashMap<>();
        if (result > 0) {
            map.put("delResult", "true");
        } else {
            map.put("delResult", "false");

        }
        ConvertUtil.sendJsonMessage(response, JSONArray.toJSONString(map));
//        response.setContentType("application/json"););
    }

    @GetMapping("getBillCountByProviderId")
    public void getBillCountByProviderId(HttpServletResponse response, String proid) throws IOException {
        List<Bill> count = billService.queryBill(null, Integer.valueOf(proid), null);
        HashMap<String, String> map = new HashMap<>();
        map.put("billCount", String.valueOf(count));
        ConvertUtil.sendJsonMessage(response, JSONArray.toJSONString(map));
    }


}

