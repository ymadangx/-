package com.edu.servlet;

import com.alibaba.fastjson.JSONArray;
import com.edu.pojo.Provider;
import com.edu.pojo.Role;
import com.edu.pojo.User;
import com.edu.service.provider.ProviderService;
import com.edu.service.role.RoleService;
import com.edu.service.user.UserService;
import com.edu.tools.Constants;
import com.edu.tools.ConvertUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class UserServlet {

    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private ProviderService providerService;

    @RequestMapping("/login")
    public String login(HttpServletRequest request, HttpServletResponse response, String userCode, String userPassword) {
        User user = userService.getUserByCodeAndPwd(userCode, userPassword);

        if (user != null) {
            request.getSession().setAttribute(Constants.USER_SESSION, user);

            return "frame";
        }

        request.setAttribute("error", "用户名或密码有误！");
        return "login";
    }

    @RequestMapping("/logout.do")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        request.getSession().removeAttribute(Constants.USER_SESSION);

        return "login";
    }

    @RequestMapping("/queryUser")
    public String queryUser(HttpServletRequest request, HttpServletResponse response, String queryname, Integer queryUserRole) {
        List<User> userList = userService.queryUser(queryname, queryUserRole);
        List<Role> roleList = roleService.queryRole();

        request.setAttribute("userList", userList);
        request.setAttribute("roleList", roleList);
        request.setAttribute("queryname", queryname);
        request.setAttribute("queryUserRole", queryUserRole);

        return "userlist";
    }

    @RequestMapping("/getProviderlist")
    public void getProviderlist(HttpServletResponse response) throws IOException {
        List<Provider> providerList = providerService.queryProvider();
        response.setContentType("application/json");
        PrintWriter printWriter = response.getWriter();
        printWriter.write(JSONArray.toJSONString(providerList));
        printWriter.flush();
    }

    @RequestMapping("/userExisted")
    public void getUserByCode(HttpServletResponse response, String userCode) throws IOException {
        User user = userService.getUserByCode(userCode);
//        response.setContentType("application/json");
        HashMap<String, Object> map = new HashMap<>();
        if (user != null) {
            map.put("userCode", "exist");
        } else {
            map.put("userCode", "noexist");
        }
        response.setContentType("application/json");
        PrintWriter printWriter = response.getWriter();
        printWriter.write(JSONArray.toJSONString(map));
        printWriter.flush();
    }

    @RequestMapping("/getRoleList")
    public void getRoleList(HttpServletResponse response) throws IOException {
        List<Role> roleList = roleService.queryRole();

//设置响应类型
        response.setContentType("application/json");
        PrintWriter printWriter = response.getWriter();
//        转化json格式
//        printWriter.write(JSONArray.toJSONString(roleList));
        String jsonstr = JSONArray.toJSONString(roleList);
        printWriter.write(jsonstr);
//        发送换回内容
        printWriter.flush();

    }

    @RequestMapping("/addUser")
    public String addUser(HttpServletRequest request, HttpServletResponse response, User user) {
//         调用添加方法
        int result = userService.addUser(user);
//        设置类型转换
        User loginedUser = (User) request.getSession().getAttribute(Constants.USER_SESSION);
        user.setCreationDate(new Date());


//        返回值大于0，添加成功，否则失败
        if (result > 0) {
            return "redirect:/queryUser";
        } else {
            return "useradd";
        }
    }

    @RequestMapping("/getUserInfo")
    public void getUserInfoById(HttpServletRequest request, HttpServletResponse response, String id) throws IOException {
        User user = userService.getUserById(id);
        String jsonStr = JSONArray.toJSONString(user);
        ConvertUtil.sendJsonMessage(response, jsonStr);

    }

    @RequestMapping("/modifyUser")
    public String modifyser(HttpServletRequest request, HttpServletResponse response, User user) throws IOException {
        User loginedUser = (User) request.getSession().getAttribute(Constants.USER_SESSION);
        user.setModifyBy(loginedUser.getId());
        user.setModifyDate(new Date());
        int result = userService.modifyUser(user);
        if (result > 0) {
//            response.sendRedirect(request.getContextPath()+"/queryUser");

            return "redirect:/queryUser";
        } else {
//            response.sendRedirect(request.getContextPath()+"/usermodify");
            return "usermodify";
        }
    }

    @PostMapping("/checkPwd")
    public void checkPassword(HttpServletRequest request, HttpServletResponse response, String oldPassword) throws IOException {
        User loginedUser = (User) request.getSession().getAttribute(Constants.USER_SESSION);
        HashMap<String, Object> map = new HashMap<>();
        map.put("result", false);
        map.put("color", "red");

        if (loginedUser == null) {
            map.put("message", "当前用户session过期，请重新登录");
        } else {
            if (oldPassword.equals(loginedUser.getUserPassword())) {
                map.put("color", "green");
                map.put("result", true);
            } else {
                map.put("message", "密码输入错误");
            }
        }
        //发送响应消息
        ConvertUtil.sendJsonMessage(response, JSONArray.toJSONString(map));
    }

    @PostMapping("/pwdmodify")
    public String modifyUserPwd(HttpServletRequest request, HttpServletResponse response, String oldPassword, String newPassword, String reNewPassword) throws IOException {
        Map<String, Object> map = new HashMap<>();
        map.put("result", false);
        User loginedUser = (User) request.getSession().getAttribute(Constants.USER_SESSION);
        if (loginedUser != null) {
            boolean result = userService.modifyUserPwd(loginedUser.getId(), newPassword, loginedUser.getId());
            if (result) {
                map.put("result", true);
                return "pwdmodify";
            }
        } else {
            map.put("message", "当前用户session过期，请重新登录");
        }
        return "pwdmodify";
    }

    @RequestMapping("/delUser")
    public void deleteUser(HttpServletResponse response, Integer uid) throws IOException {
        int result = userService.deleteUser(uid);
        HashMap<String, String> map = new HashMap<>();
        if (result > 0) {
            map.put("delResult", "true");
        } else {
            map.put("delResult", "false");
        }
        ConvertUtil.sendJsonMessage(response, JSONArray.toJSONString(map));
    }
}
