package com.edu.servlet;

import com.alibaba.fastjson.JSONArray;
import com.edu.pojo.Provider;
import com.edu.service.provider.ProviderService;
import com.edu.tools.ConvertUtil;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Controller
public class ProviderServlet {
    @Autowired
    ProviderService providerService;

    @RequestMapping("/queryProvider")
    public String queryProvider(HttpServletRequest request, HttpServletResponse response, @Param("queryProCode") String queryProCode, @Param("queryProName") String queryProName) {
        System.out.println(queryProCode);
        System.out.println(queryProName);
        List<Provider> providerList = providerService.queryProvider(queryProCode, queryProName);
        request.setAttribute("providerList", providerList);
        return "providerlist";
    }

    @RequestMapping("/addProvider")
    public String addProvider(HttpServletRequest request, HttpServletResponse response) {
        Provider provider = new Provider();
        provider.setProCode(request.getParameter("proCode"));
        provider.setProName(request.getParameter("proName"));
        provider.setProDesc(request.getParameter("proDesc"));
        provider.setProContact(request.getParameter("proContact"));
        provider.setProPhone(request.getParameter("proPhone"));
        provider.setProAddress(request.getParameter("proAddress"));
        provider.setProFax(request.getParameter("proFax"));
        provider.setCreatedBy(1);
        provider.setCreationDate(new Date());
        providerService.addProvider(provider);
        return "redirect:/queryProvider";
    }

    @GetMapping("/providerModifyPage")
    public String providerModify(HttpServletRequest request, int proid) {
        Provider provider = providerService.queryProviderById(proid);
        request.setAttribute("proid", proid);
        request.setAttribute("provider", provider);
        return "providermodify";
    }

    @GetMapping("/providerViewPage")
    public String providerView(HttpServletRequest request, int proid) {
        Provider provider = providerService.queryProviderById(proid);
        request.setAttribute("proid", proid);
        request.setAttribute("provider", provider);
        return "providerview";
    }

    @PostMapping("/providerModify")
    public String providerModify(HttpServletRequest request, Provider provider) {
        boolean result = providerService.modifyProvider(provider);
        if (result) {
            return "redirect:/queryProvider";
        } else {
            return "providermodify";
        }
    }

    @PostMapping("/delProvider")
    public void delProvider(HttpServletResponse response, int proid) throws IOException {
        boolean result = providerService.delProvider(proid);
        HashMap<String, Boolean> map = new HashMap<>();
        map.put("delResult", result);
        // 使用 ConvertUtil 发送 JSON 格式的响应
        ConvertUtil.sendJsonMessage(response, JSONArray.toJSONString(map));
    }

}
