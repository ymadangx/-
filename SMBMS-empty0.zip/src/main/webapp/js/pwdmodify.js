let oldPassword = null;
let newPassword = null;
let reNewPassword = null;
let saveBtn = null;

$(function () {
    oldPassword = $("#oldPassword");
    newPassword = $("#newPassword");
    reNewPassword = $("#reNewPassword");
    saveBtn = $("#save");

    oldPassword.next().html("*");
    newPassword.next().html("*");
    reNewPassword.next().html("*");

    oldPassword.on("blur", function () {
        $.ajax({
            type: "POST",
            url: path + "/checkPwd",
            data: {method: "pwdmodify", oldPassword: oldPassword.val()},
            dataType: "json",
            success: function (data) {
                if (data.result) {//旧密码正确
                    validateTip(oldPassword.next(), {"color": data.color}, imgYes, true);
                } else {//旧密码输入不正确
                    validateTip(oldPassword.next(), {"color": data.color}, imgNo + " " + data.message, false);
                }
            },
            error: function (xhr, status, error) {
                //请求出错
                console.error(xhr.responseText);
                validateTip(oldPassword.next(), {"color": "red"}, imgNo + " 请求错误", false);
            }
        });


    }).on("focus", function () {
        validateTip(oldPassword.next(), {"color": "#666666"}, "* 请输入原密码", false);
    });

    newPassword.on("focus", function () {
        validateTip(newPassword.next(), {"color": "#666666"}, "* 密码长度必须是大于6小于20", false);
    }).on("blur", function () {
        if (newPassword.val() != null && newPassword.val().length > 6
            && newPassword.val().length < 20) {
            validateTip(newPassword.next(), {"color": "green"}, imgYes, true);
        } else {
            validateTip(newPassword.next(), {"color": "red"}, imgNo + " 密码输入不符合规范，请重新输入", false);
        }
    });


    reNewPassword.on("focus", function () {
        validateTip(reNewPassword.next(), {"color": "#666666"}, "* 请输入与上面一致的密码", false);
    }).on("blur", function () {
        if (reNewPassword.val() != null && reNewPassword.val().length > 6
            && reNewPassword.val().length < 20 && newPassword.val() === reNewPassword.val()) {
            validateTip(reNewPassword.next(), {"color": "green"}, imgYes, true);
        } else {
            validateTip(reNewPassword.next(), {"color": "red"}, imgNo + " 两次密码输入不一致，请重新输入", false);
        }
    });


    saveBtn.on("click", function () {
        oldPassword.blur();
        newPassword.blur();
        reNewPassword.blur();
        if (oldPassword.attr("validateStatus") === "true"
            && newPassword.attr("validateStatus") === "true"
            && reNewPassword.attr("validateStatus") === "true") {
            if (confirm("确定要修改密码？")) {
                $("#userForm").submit();
            }
        }
    });
});