let providerObj;

//供应商管理页面上点击删除按钮弹出删除框(providerlist.jsp)
function deleteProvider(obj) {
    cancleBtn();
    $.ajax({
        type: "GET",
        url: path + "/getBillCountByProviderId",
        data: {proid: obj.attr("proid")},
        dataType: "json",
        success: function (data) {
            if (data > 0) {//该供应商下有多条订单记录
                alert("对不起，该供应商【" + obj.attr("proname") + "】下有【" + data + "】条订单，不能删除");
            } else {//该供应商名下无订单记录，进行删除操作
                $.ajax({
                    type: "POST",
                    url: path + "/delProvider",
                    data: {proid: obj.attr("proid")},
                    dataType: "json",
                    success: function (data) {
                        console.log(data)
                        if (data.delResult) {//删除成功：移除删除行
                            obj.parents("tr").remove();
                        } else {//删除失败
                            alert("对不起，删除供应商【" + obj.attr("proname") + "】失败");
                        }
                    },
                    error: function (xhr, status, error) {
                        // 输出更详细的错误信息
                        console.error(xhr.responseText);
                        alert("对不起，删除失败");
                    }
                });
            }
        },
        error: function (data) {
            //alert("对不起，删除失败");
            alert("对不起，获取供应商订单数失败");
        }
    });
}


function openYesOrNoDLG() {
    $('.zhezhao').css('display', 'block');
    $('#removeProv').fadeIn();
}

function cancleBtn() {
    $('.zhezhao').css('display', 'none');
    $('#removeProv').fadeOut();
}

function changeDLGContent(contentStr) {
    var p = $(".removeMain").find("p");
    p.html(contentStr);
}

$(function () {
    $(".viewProvider").on("click", function () {
        //将被绑定的元素（a）转换成jquery对象，可以使用jquery方法
        var obj = $(this);
        window.location.href = path + "/providerViewPage?proid=" + obj.attr("proid");
    });

    $(".modifyProvider").on("click", function () {
        var obj = $(this);
        window.location.href = path + "/providerModifyPage?proid=" + obj.attr("proid");
    });

    $('#no').click(function () {
        cancleBtn();
    });

    $('#yes').click(function () {
        deleteProvider(providerObj);
    });

    $(".deleteProvider").on("click", function () {
        providerObj = $(this);
        changeDLGContent("你确定要删除供应商【" + providerObj.attr("proname") + "】吗？");
        openYesOrNoDLG();
    });
});